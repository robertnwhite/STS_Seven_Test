package com.coffeecup.sevenmlm.test01;

public class Person {
	
	public void speak(){
		System.out.println("Hello I am a person with a name of : "+ title.toString()+" " +name.toString()
		+" "+lastName.toString());
	}
	
	private String name= "Robert";
	private String title = "Mr.";
	private String lastName ="White";
	

}
