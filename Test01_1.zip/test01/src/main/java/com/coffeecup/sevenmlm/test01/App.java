package com.coffeecup.sevenmlm.test01;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World - you big nasty!" );
        Person newPerson = new Person();
        newPerson.speak();
    }
}
